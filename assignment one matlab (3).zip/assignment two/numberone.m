%%GROUP 7 MATLAB ASSIGNMENT ONE
%reading an excell sheet into matlab
MS = readtable("C:\Users\sseba\Desktop\assignment two\data set assignment one.xlsx");
disp(MS)
% separating data from each year into diffrent tables
MS2010 =MS(MS.year==2010, : );%extraction of unique years(2010)
MS2011 =MS(MS.year==2011, : );%extraction of unique years(2011)
MS2012 =MS(MS.year==2012, : );%extraction of unique years(2012)
MS2013 =MS(MS.year==2013, : );%extraction of unique years(2013)
MS2014 =MS(MS.year==2014, : );%extraction of unique years(2014)
MS2015 =MS(MS.year==2015, : );%extraction of unique years(2015)
MS2016 =MS(MS.year==2016, : );%extraction of unique years(2016)
MS2017 =MS(MS.year==2017, : );%extraction of unique years(2017)
MS2018 =MS(MS.year==2018, : );%extraction of unique years(2018)
MS2019 =MS(MS.year==2019, : );%extraction of unique years(2019)
MS2020 =MS(MS.year==2020, : );%extraction of unique years(2020)
MS2021 =MS(MS.year==2021, : );%extraction of unique years(2021)
MS2022 =MS(MS.year==2022, : );%extraction of unique years(2022)
MS2023 =MS(MS.year==2023, : );%extraction of unique years(2023)
MS2024 =MS(MS.year==2024, : );%extraction of unique years(2024)
MS2025 =MS(MS.year==2025, : );%extraction of unique years(2025)
%conversion of tables into struts
S2010=table2struct(MS2010);%for MS2010
S2011=table2struct(MS2011);%for MS2011
S2012=table2struct(MS2012);%for MS2012
S2013=table2struct(MS2013);%for MS2013
S2014=table2struct(MS2014);%for MS2014
S2015=table2struct(MS2015);%for MS2015
S2016=table2struct(MS2016);%for MS2016
S2017=table2struct(MS2017);%for MS2017
S2018=table2struct(MS2024);%for MS2018
S2019=table2struct(MS2024);%for MS2019
S2020=table2struct(MS2024);%for MS2020
S2021=table2struct(MS2024);%for MS2021
S2022=table2struct(MS2024);%for MS2022
S2023=table2struct(MS2024);%for MS2023
S2024=table2struct(MS2024);%for MS2024
S2025=table2struct(MS2024);%for MS2025
%Writing table into matlab
workbook = "C:\Users\sseba\Desktop\assignment two\all tables number one.xlsx";
%writing each table on adiffrent workbook
writetable(MS2010,workbook,'sheet','MS2010');
writetable(MS2011,workbook,'sheet','MS2011');
writetable(MS2012,workbook,'sheet','MS2012');
writetable(MS2013,workbook,'sheet','MS2013');
writetable(MS2014,workbook,'sheet','MS2014');
writetable(MS2015,workbook,'sheet','MS2015');
writetable(MS2016,workbook,'sheet','MS2016');
writetable(MS2017,workbook,'sheet','MS2017');
writetable(MS2018,workbook,'sheet','MS2018');
writetable(MS2019,workbook,'sheet','MS2019');
writetable(MS2020,workbook,'sheet','MS2020');
writetable(MS2021,workbook,'sheet','MS2021');
writetable(MS2022,workbook,'sheet','MS2022');
writetable(MS2023,workbook,'sheet','MS2023');
writetable(MS2024,workbook,'sheet','MS2024');
writetable(MS2025,workbook,'sheet','MS2025');

