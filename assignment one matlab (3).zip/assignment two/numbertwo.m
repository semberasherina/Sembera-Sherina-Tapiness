% defining struct
Members=struct('name',{},'age',{},'tribe',{},'interests',{},'village',{},'religion',{},'course',{},'district',{},'facialrepresentation',{});
%Member 1
Member(1).name='SSEBAKIJJE HOSEA';
Member(1).age=21;
Member(1).tribe='MUGANDA';
Member(1).interests='SINGING';
Member(1).village='NAKISUNGA';
Member(1).religion='SDA';
Member(1).course='AMI';
Member(1).district='MUKONO';
Member(1).facialrepresentation='C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\DSC_6414.JPG';
%Member 2
Member(2).name = 'NYERO MARIA';
Member(2).tribe = 'LANGI';
Member(2).interests = 'COOKING';
Member(2).village = 'NGETTA';
Member(2).religion = 'CATHOLIC';
Member(2).course = 'WAR';
Member(2).district = 'LIRA';
Member(2).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\maria.jpg';
%member 3
Member(3).name = 'KAKURU OBADIAH';
Member(3).age = 22;
Member(3).tribe = 'MUNYANKOLE';
Member(3).interests = 'FOOTBALL';
Member(3).religion = 'ANGLICAN';
Member(3).course = 'WAR';
Member(3).district = 'NTUNGAMO';
Member(3).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\OBADIA.jpg';
% Member4
Member(4).name = 'Sembera sherina Tapiness';
Member(4).age = 21;
Member(4).tribe = 'Musoga';
Member(4).interests = 'Eating';
Member(4).village = 'Bugenbe';
Member(4).religion = 'Anglican';
Member(4).course = 'meb';
Member(4).course = 'Meb';
Member(4).district = 'Jinja';
Member(4).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\SHERINA.jpg';
%Member 5
Member(5).name = 'Esarait Brian';
Member(5).age = 21;
Member(5).tribe = 'Iteso';
Member(5).interests = 'RUGY';
Member(5).village = 'SOROTI';
Member(5).religion = 'ANGLICAN';
Member(5).course = 'MEB';
Member(5).district = 'SOROTI';
Member(5).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\ESIRIAT.jpg';
% Member 6
Member(6).name = 'Adipo Hope Odware';
Member(6).age = 21;
Member(6).tribe = 'Atesot';
Member(6).interests = 'Reading';
Member(6).village = 'Bukedea';
Member(6).religion = 'BORNAGAIN';
Member(6).course = 'MEB';
Member(6).district = 'BUKEDEA';
% Member 7
Member(7).name = 'GUDOI ALLAN';
Member(7).age = 22;
Member(7).tribe = 'Mugisu';
Member(7).interests = 'Research';
Member(7).village = 'Majanga';
Member(7).religion = 'Anglican';
Member(7).course = 'WAR';
Member(7).district = 'Mbale';
Member(7).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\GUDOI.jpg';
% Member 8
Member(8).name = 'Kobusingye Bethline';
Member(8).course = 'PTI';
Member(8).district = 'Ntungamo';
Member(8).village = 'Itojo';
Member(8).tribe = 'Munyankore';
Member(8).religion = 'Protestant';
Member(8).age = 21 ;
Member(8).interests = 'Watching movies';
Member(8).facialrepresentation = 'C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\bethelene.jpg';